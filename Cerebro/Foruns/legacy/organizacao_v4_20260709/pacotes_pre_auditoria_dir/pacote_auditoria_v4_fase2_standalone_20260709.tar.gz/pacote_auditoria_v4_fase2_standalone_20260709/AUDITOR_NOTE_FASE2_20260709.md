# Nota ao auditor — Fase 2 V4

Este pacote standalone executavel foi gerado a partir das fontes canonicas e dos espelhos limpos em `Cerebro/Foruns/v4/`.

Fontes canonicas dentro do pacote:

```text
diretrizes/
v4_diretrizes/
v4_data/
```

Espelhos para leitura/auditoria:

```text
Cerebro/Foruns/v4/diretrizes/
Cerebro/Foruns/v4/v4_diretrizes/
Cerebro/Foruns/v4/v4_data/
Cerebro/Foruns/v4/foruns/
Cerebro/Foruns/v4/cartas/
```

Rode a partir da raiz extraida:

```bash
python3 -m v4_diretrizes.test_contracts
```

Resultado esperado:

```text
OK 52 contract tests
```

Escopo: Fase 2 e somente `shadow_redacao`. Nao ha chamada LLM externa, nao ha WordPress real e nao ha publicacao real. No caso 261439, `collection_request.status=recommended` libera `shadow_redacao`, mas bloqueia `redator_real_llm` e `publicacao_real` ate coleta USTR/Federal Register.

Nao auditar copias antigas em `Cerebro/Foruns/legacy/organizacao_v4_20260709/`. O legado existe apenas para rastreabilidade.
