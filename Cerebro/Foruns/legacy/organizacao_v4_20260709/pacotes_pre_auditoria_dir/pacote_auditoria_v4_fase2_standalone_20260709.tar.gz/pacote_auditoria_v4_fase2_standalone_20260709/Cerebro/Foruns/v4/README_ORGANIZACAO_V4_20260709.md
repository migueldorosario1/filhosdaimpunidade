# Organizacao V4 em Foruns

Data: 2026-07-09

Diretorio ativo:

```text
Cerebro/Foruns/v4/
```

## Regra principal

```text
Cerebro/Foruns/v4/ e apenas espelho de auditoria e material para colar em Fable/GPT 5.5/AGY.
Nao e fonte viva de execucao.
Nao editar aqui como origem.
```

## Estrutura ativa de espelhos

```text
foruns/        espelho/contexto das discussoes V4 para auditoria
cartas/        cartas V4 para colar em auditores e pareceristas
diretrizes/    espelho de diretrizes/ canonico
v4_diretrizes/ espelho de v4_diretrizes/ canonico
v4_data/       espelho de v4_data/ canonico
pacotes/       pacotes zipados gerados a partir das fontes canonicas
```

Pacote atual para Fable/GPT 5.5/AGY:

```text
Cerebro/Foruns/v4/pacotes/pacote_auditoria_v4_fase2_standalone_20260709.tar.gz
```

Comando esperado dentro do pacote extraido:

```bash
python3 -m v4_diretrizes.test_contracts
```

Resultado esperado:

```text
OK 52 contract tests
```

## Legado

Duplicatas, aliases e pacotes intermediarios foram movidos para:

```text
Cerebro/Foruns/legacy/organizacao_v4_20260709/
```

Nao usar `legacy` para auditoria corrente. Ele existe apenas para rastreabilidade e recuperacao.

## Fontes vivas de execucao

Os espelhos em `Cerebro/Foruns/v4/` sao para revisao humana. As fontes vivas de execucao continuam na raiz do workspace:

```text
diretrizes/
v4_diretrizes/
v4_data/
```

Qualquer mudanca de codigo, contrato ou dado de trabalho deve ser feita nas fontes vivas e depois reconciliada com os espelhos V4.
